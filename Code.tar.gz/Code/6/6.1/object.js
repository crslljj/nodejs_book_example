exports.show = function(){
	console.log('this is a object');
}