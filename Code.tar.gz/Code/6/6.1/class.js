module.exports = function(){
	this.show = function(){
		console.log('this is a class');
	}
}