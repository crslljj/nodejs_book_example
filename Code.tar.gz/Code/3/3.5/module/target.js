/* target.js */
module.exports = function(){
	this.encode = function(){
		// for noting
		console.log('no this function exist');
	}
	this.decode = function(){
		// for noting
		console.log('no this function exist');
	}
}