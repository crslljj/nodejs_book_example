var Hello = require('./build/Release/hello.node');
console.log(Hello.hello());
