/* client.js */
var Adapter = require('./adapter');

var target = new Adapter();
target.request();
