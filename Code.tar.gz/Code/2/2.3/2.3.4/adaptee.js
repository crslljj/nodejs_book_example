/* adaptee.js */
module.exports = function (){
	this.specialRequest = function(){
		console.log('Adaptee::specialRequest');
	}
}