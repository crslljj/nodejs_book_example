/* product.js */
module.exports = function(){
	this.getProduct = function(){
		console.log('product is get from class of Product');
	}
}