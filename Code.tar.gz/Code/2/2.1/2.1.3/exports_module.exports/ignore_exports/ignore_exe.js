var Book = require('./ignore_exports.js');
console.log(Book);
console.log(Book.name);
console.log(Book.showName());