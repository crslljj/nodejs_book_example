module.exports = 'test for module.exorts ignore!';  
exports.name = 'danhuang';
exports.showName = function() {  
    console.log('My name is Danhuang');  
}; 
console.log(module.exports );