/**
 *
 * @class Animal
 */
module.exports = function(){
	this.say = function(){
		console.log('noting');
	}
}