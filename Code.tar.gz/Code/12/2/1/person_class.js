/**
 *
 * @type  class
 * @class Person
 */
module.exports = function(){
	/**
	 *
	 * person eat action
	 */
	this.eat = function(){
		console.log('eat');
	}
	
	/**
	 *
	 * person say action
	 */
	this.say = function(){
		console.log('say');
	}
}